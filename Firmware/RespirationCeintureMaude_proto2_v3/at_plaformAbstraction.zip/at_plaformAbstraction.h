/**
 * @def AT_PLATFORMABSTRACTION_H
 * @brief 	This librarie is used to do an abstraction of the different platforms
 * 			so that the code build using this library may be reused on ST,
 * 			Arduino, Atmel, etc.
 *
 */

#ifndef AT_PLATFORMABSTRACTION_H
#define AT_PLATFORMABSTRACTION_H



	//! [Digital Pin Abstraction]
	/** In order to be able to use the same functions on multiple platforms (STM32, Atmel, Arduino), we create a standard
	 *  function format by creating a macro that calls the actual function on the target platform. Create the macro that
	 *  matches you platform need here
	 */

		// For STM32
		//#define digitalPinRead(pin,port)  ((unsigned char)HAL_GPIO_ReadPin((GPIO_TypeDef*)port, (uint16_t)pin))
		//#define digitalPinWrite(pin,port,state) (HAL_GPIO_WritePin((GPIO_TypeDef*)port, (uint16_t)pin, (GPIO_PinState)state))

		// Arduino Example (Not tested yet)
		#include "Arduino.h"
		
		#define digitalPinRead(pin,port)  ((unsigned char)digitalRead(pin))
		#define digitalPinWrite(pin,port,state) ( digitalWrite((uint32_t)pin, (uint32_t)state) )
	//! [Digital Pin Abstraction]


#endif
